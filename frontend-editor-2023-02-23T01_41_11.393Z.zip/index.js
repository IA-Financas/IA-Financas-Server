
//experimental hover effect 
let logoJump= true;
// movement for animations
const speed_Movement= 5;
//functions
function openRepositories(){

}

function openProjects(){

}

function rollDown_site(){

}

function rollUp_site(){

}
function modal(){
  if(PointerEvent= hover){
  alert= "Inscreva-se no newsletter!"
  }
} 